Keras is an object-oriented API for defining and training neural networks.

This module contains a pure-TensorFlow implementation of the Keras API,
allowing for deep integration with TensorFlow functionality.

See [keras.io](https://keras.io) for complete documentation and user guides.
